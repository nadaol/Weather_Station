void connect();
int fahrenheit(float c);
int fahr_asm(int a, int b);
